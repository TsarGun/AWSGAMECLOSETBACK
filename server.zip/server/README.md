# client

> IT354 Game Closet

Open a command prompt/terminal window in the server folder and user the command npm start to run the Express.js based backend. On launch, the server project will request a valid login for use with mongoDB; a generic user test with password abc123 was created specifically for demonstrating the app